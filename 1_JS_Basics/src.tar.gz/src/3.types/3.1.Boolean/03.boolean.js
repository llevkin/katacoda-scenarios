let a = new Boolean(true),
    b = new Boolean(true);

console.log(a, b);
console.log(a === b, a === true);