let str = 'Привет';

console.log(1, str.toUpperCase());

console.log(2, typeof 0);

console.log(3, typeof new Number(0));

console.log(4, false === new Boolean(false));

console.log(5, false === Boolean(false));