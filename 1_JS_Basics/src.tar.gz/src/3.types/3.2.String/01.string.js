let a = 'Hello world',
    b = 'Hello world';

console.log(a, b, a === b);

a = String('Hello world');
b = String('Hello world');

console.log(a, b, a === b);