let a = new String('Hello world'),
    b = new String('Hello world');

console.log(a === b);