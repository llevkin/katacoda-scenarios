let a = new Boolean(true),
    b = new Boolean(false);

console.log(a, b);
console.log(a === b, a === true, b === false);