const a = 1;
{
  const a = 2;
  console.log(a);
}
console.log(a);