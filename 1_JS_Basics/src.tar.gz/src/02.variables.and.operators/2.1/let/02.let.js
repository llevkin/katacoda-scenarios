let a = 1;
let a = 2;
console.log(a);